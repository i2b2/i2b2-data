-- Update age_in_years_num based on birthdate
-- Postgres version
UPDATE PATIENT_DIMENSION
Set AGE_IN_YEARS_NUM =
case when DEATH_DATE is null then
trunc(EXTRACT(
                EPOCH FROM (now() - (birth_date)
)/3600)/8766)
else trunc(EXTRACT(
                EPOCH FROM (death_date - (birth_date)
)/3600)/8766)
End