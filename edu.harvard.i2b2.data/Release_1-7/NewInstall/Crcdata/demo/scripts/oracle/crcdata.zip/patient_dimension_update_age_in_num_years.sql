-- Update age_in_years_num based on birthdate
-- Oracle version
UPDATE PATIENT_DIMENSION
Set AGE_IN_YEARS_NUM=
--select age_in_years_num, trunc((( sysdate - birth_date)*24)/8766),
case when DEATH_DATE is null then
trunc((( sysdate - birth_date)*24)/8766)
else
trunc((( death_date - birth_date)*24)/8766)
end